﻿namespace NightVision
{
    public interface ISaveCheck
    {
        bool ShouldBeSaved();
    }
}