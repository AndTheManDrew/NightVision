﻿using JetBrains.Annotations;
using Verse;

namespace NightVision
{
    [UsedImplicitly]
    public class Stealth_ModExtension : DefModExtension
    {
        [UsedImplicitly]
        public float lowlightbodysizefactor;
    }
}