﻿namespace NightVision
{
    public enum Tab
    {
        General,
        Combat,
        Races,
        Apparel,
        Bionics,
        Debug
    }
}